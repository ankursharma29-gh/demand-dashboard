import { useState } from "react";

export interface BrandConfig {
  companyName: string;
  productName: string;
  accentColor: string;
  accentDark: string;
  topbarColor: string;
  bgColor: string;
  userName: string;
  userInitials: string;
  greeting: string;
}

export const DEFAULT_CONFIG: BrandConfig = {
  companyName: "alo",
  productName: "Yoga",
  accentColor: "#019481",
  accentDark: "#017A6A",
  topbarColor: "#000000",
  bgColor: "#EDEDED",
  userName: "Tracy",
  userInitials: "T",
  greeting: "Let's Start Planning!",
};

const PRESETS: { name: string; config: Partial<BrandConfig> }[] = [
  {
    name: "Alo (Default)",
    config: {
      accentColor: "#019481",
      accentDark: "#017A6A",
      topbarColor: "#000000",
      bgColor: "#EDEDED",
    },
  },
  {
    name: "Navy & Gold",
    config: {
      accentColor: "#C9A84C",
      accentDark: "#A8892E",
      topbarColor: "#0D1B2A",
      bgColor: "#F0EDE8",
    },
  },
  {
    name: "Slate & Coral",
    config: {
      accentColor: "#E8614D",
      accentDark: "#C94A38",
      topbarColor: "#2D3748",
      bgColor: "#F7F5F3",
    },
  },
  {
    name: "Forest & Cream",
    config: {
      accentColor: "#3A7D44",
      accentDark: "#2D6235",
      topbarColor: "#1A2E1A",
      bgColor: "#F5F2EC",
    },
  },
  {
    name: "Midnight Purple",
    config: {
      accentColor: "#7C3AED",
      accentDark: "#6129C7",
      topbarColor: "#1E1030",
      bgColor: "#F3F0FA",
    },
  },
];

interface Props {
  config: BrandConfig;
  onUpdate: (config: BrandConfig) => void;
}

export default function BrandSettings({ config, onUpdate }: Props) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<BrandConfig>(config);
  const [tab, setTab] = useState<"brand" | "colors" | "user">("brand");

  const handleApply = () => {
    onUpdate(draft);
    setOpen(false);
  };

  const handleReset = () => {
    setDraft(DEFAULT_CONFIG);
    onUpdate(DEFAULT_CONFIG);
  };

  const applyPreset = (preset: Partial<BrandConfig>) => {
    const next = { ...draft, ...preset };
    setDraft(next);
  };

  const field = (
    label: string,
    key: keyof BrandConfig,
    type: "text" | "color" = "text"
  ) => (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <label
        style={{
          fontSize: 10,
          fontWeight: 700,
          letterSpacing: ".5px",
          textTransform: "uppercase",
          color: "#666",
        }}
      >
        {label}
      </label>
      {type === "color" ? (
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <input
            type="color"
            value={draft[key] as string}
            onChange={(e) => setDraft((d) => ({ ...d, [key]: e.target.value }))}
            style={{
              width: 36,
              height: 36,
              border: "1.5px solid #C8C8C4",
              borderRadius: 6,
              cursor: "pointer",
              padding: 2,
              background: "white",
            }}
          />
          <input
            type="text"
            value={draft[key] as string}
            onChange={(e) => setDraft((d) => ({ ...d, [key]: e.target.value }))}
            style={{
              flex: 1,
              border: "1.5px solid #C8C8C4",
              borderRadius: 6,
              padding: "6px 10px",
              fontSize: 12,
              fontFamily: "'DM Mono', monospace",
              outline: "none",
            }}
          />
        </div>
      ) : (
        <input
          type="text"
          value={draft[key] as string}
          onChange={(e) => setDraft((d) => ({ ...d, [key]: e.target.value }))}
          style={{
            border: "1.5px solid #C8C8C4",
            borderRadius: 6,
            padding: "7px 10px",
            fontSize: 12,
            fontFamily: "inherit",
            outline: "none",
          }}
        />
      )}
    </div>
  );

  return (
    <>
      {/* Floating trigger button */}
      <button
        onClick={() => {
          setDraft(config);
          setOpen(true);
        }}
        title="Customize Branding"
        style={{
          position: "fixed",
          bottom: 20,
          right: 20,
          zIndex: 1000,
          width: 44,
          height: 44,
          borderRadius: "50%",
          background: config.accentColor,
          border: "none",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "0 4px 16px rgba(0,0,0,.18), 0 1px 4px rgba(0,0,0,.12)",
          transition: "transform .15s, box-shadow .15s",
        }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.08)";
          (e.currentTarget as HTMLButtonElement).style.boxShadow =
            "0 6px 20px rgba(0,0,0,.22), 0 2px 6px rgba(0,0,0,.14)";
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLButtonElement).style.transform = "scale(1)";
          (e.currentTarget as HTMLButtonElement).style.boxShadow =
            "0 4px 16px rgba(0,0,0,.18), 0 1px 4px rgba(0,0,0,.12)";
        }}
      >
        <svg
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          stroke="white"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="3" />
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
        </svg>
      </button>

      {/* Panel */}
      {open && (
        <>
          {/* Backdrop */}
          <div
            onClick={() => setOpen(false)}
            style={{
              position: "fixed",
              inset: 0,
              zIndex: 999,
              background: "rgba(0,0,0,.25)",
              backdropFilter: "blur(2px)",
            }}
          />

          {/* Drawer */}
          <div
            style={{
              position: "fixed",
              top: 0,
              right: 0,
              bottom: 0,
              width: 320,
              zIndex: 1001,
              background: "#FFFFFF",
              boxShadow: "-8px 0 32px rgba(0,0,0,.14)",
              display: "flex",
              flexDirection: "column",
              fontFamily: "'Inter', sans-serif",
              fontSize: 13,
              animation: "slideIn .2s ease",
            }}
          >
            <style>{`
              @keyframes slideIn {
                from { transform: translateX(100%); }
                to { transform: translateX(0); }
              }
            `}</style>

            {/* Header */}
            <div
              style={{
                padding: "16px 20px 14px",
                borderBottom: "1px solid #EAEAE6",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                background: config.topbarColor,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: 6,
                    background: config.accentColor,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="white"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <circle cx="12" cy="12" r="3" />
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                  </svg>
                </div>
                <div>
                  <div
                    style={{
                      fontSize: 13,
                      fontWeight: 700,
                      color: "white",
                      letterSpacing: "-.2px",
                    }}
                  >
                    Brand Settings
                  </div>
                  <div
                    style={{
                      fontSize: 10,
                      color: "rgba(255,255,255,.5)",
                      letterSpacing: ".5px",
                      textTransform: "uppercase",
                    }}
                  >
                    Live customization
                  </div>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: 6,
                  border: "1px solid rgba(255,255,255,.15)",
                  background: "rgba(255,255,255,.08)",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "rgba(255,255,255,.6)",
                }}
              >
                <svg
                  width="12"
                  height="12"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            {/* Tabs */}
            <div
              style={{
                display: "flex",
                borderBottom: "1px solid #EAEAE6",
                background: "#FAFAFA",
              }}
            >
              {(["brand", "colors", "user"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  style={{
                    flex: 1,
                    padding: "10px 0",
                    border: "none",
                    borderBottom:
                      tab === t
                        ? `2px solid ${draft.accentColor}`
                        : "2px solid transparent",
                    background: "transparent",
                    fontSize: 11,
                    fontWeight: 700,
                    textTransform: "uppercase",
                    letterSpacing: ".5px",
                    cursor: "pointer",
                    color: tab === t ? draft.accentColor : "#999",
                    fontFamily: "inherit",
                    transition: "all .15s",
                  }}
                >
                  {t === "brand" ? "Brand" : t === "colors" ? "Colors" : "User"}
                </button>
              ))}
            </div>

            {/* Content */}
            <div style={{ flex: 1, overflowY: "auto", padding: "16px 20px" }}>
              {tab === "brand" && (
                <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  <div
                    style={{
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: ".8px",
                      textTransform: "uppercase",
                      color: "#AAA",
                      marginBottom: -4,
                    }}
                  >
                    Logo Text
                  </div>
                  {field("Company Name (line 1)", "companyName")}
                  {field("Sub-title (line 2)", "productName")}
                  {field("Page Greeting", "greeting")}

                  <div
                    style={{
                      marginTop: 8,
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: ".8px",
                      textTransform: "uppercase",
                      color: "#AAA",
                    }}
                  >
                    Preview
                  </div>
                  <div
                    style={{
                      background: draft.topbarColor,
                      borderRadius: 8,
                      padding: "12px 16px",
                      display: "flex",
                      alignItems: "center",
                      gap: 10,
                    }}
                  >
                    <div
                      style={{
                        width: 28,
                        height: 28,
                        borderRadius: 6,
                        background: draft.accentColor,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                      }}
                    >
                      <svg width="16" height="16" viewBox="0 0 32 32" fill="none">
                        <path d="M8 24 C8 24 8 10 16 8 C24 10 24 24 24 24" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                        <line x1="16" y1="8" x2="16" y2="24" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.7"/>
                      </svg>
                    </div>
                    <div style={{ lineHeight: 1.2 }}>
                      <div
                        style={{
                          fontSize: 14,
                          fontWeight: 900,
                          color: draft.accentColor,
                          letterSpacing: "-.4px",
                        }}
                      >
                        {draft.companyName || "alo"}
                      </div>
                      <div
                        style={{
                          fontSize: 7,
                          fontWeight: 600,
                          letterSpacing: "2px",
                          textTransform: "uppercase",
                          color: "rgba(255,255,255,.35)",
                        }}
                      >
                        {draft.productName || "Planner Pro"}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {tab === "colors" && (
                <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  <div
                    style={{
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: ".8px",
                      textTransform: "uppercase",
                      color: "#AAA",
                      marginBottom: -4,
                    }}
                  >
                    Theme Presets
                  </div>
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "1fr 1fr",
                      gap: 6,
                    }}
                  >
                    {PRESETS.map((p) => (
                      <button
                        key={p.name}
                        onClick={() => applyPreset(p.config)}
                        style={{
                          border: "1.5px solid #EAEAE6",
                          borderRadius: 8,
                          padding: "8px 10px",
                          cursor: "pointer",
                          background: "white",
                          fontFamily: "inherit",
                          fontSize: 11,
                          fontWeight: 600,
                          color: "#333",
                          display: "flex",
                          alignItems: "center",
                          gap: 8,
                          textAlign: "left",
                          transition: "border-color .12s",
                        }}
                        onMouseEnter={(e) => {
                          (e.currentTarget as HTMLButtonElement).style.borderColor =
                            draft.accentColor;
                        }}
                        onMouseLeave={(e) => {
                          (e.currentTarget as HTMLButtonElement).style.borderColor =
                            "#EAEAE6";
                        }}
                      >
                        <div style={{ display: "flex", gap: 3 }}>
                          <div
                            style={{
                              width: 12,
                              height: 12,
                              borderRadius: 3,
                              background: p.config.accentColor,
                            }}
                          />
                          <div
                            style={{
                              width: 12,
                              height: 12,
                              borderRadius: 3,
                              background: p.config.topbarColor,
                            }}
                          />
                        </div>
                        {p.name}
                      </button>
                    ))}
                  </div>

                  <div
                    style={{
                      marginTop: 4,
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: ".8px",
                      textTransform: "uppercase",
                      color: "#AAA",
                    }}
                  >
                    Custom Colors
                  </div>
                  {field("Accent Color (Primary)", "accentColor", "color")}
                  {field("Accent Dark (Hover)", "accentDark", "color")}
                  {field("Topbar Background", "topbarColor", "color")}
                  {field("Page Background", "bgColor", "color")}
                </div>
              )}

              {tab === "user" && (
                <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  <div
                    style={{
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: ".8px",
                      textTransform: "uppercase",
                      color: "#AAA",
                      marginBottom: -4,
                    }}
                  >
                    User Profile
                  </div>
                  {field("Full Name", "userName")}
                  {field("Initials (2 chars)", "userInitials")}

                  <div
                    style={{
                      marginTop: 8,
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: ".8px",
                      textTransform: "uppercase",
                      color: "#AAA",
                    }}
                  >
                    Preview
                  </div>
                  <div
                    style={{
                      background: draft.topbarColor,
                      borderRadius: 8,
                      padding: "10px 14px",
                      display: "flex",
                      alignItems: "center",
                      gap: 10,
                    }}
                  >
                    <div
                      style={{
                        width: 30,
                        height: 30,
                        borderRadius: "50%",
                        background: `linear-gradient(135deg, ${draft.accentColor}, ${draft.accentDark})`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 11,
                        fontWeight: 700,
                        color: "white",
                        flexShrink: 0,
                      }}
                    >
                      {(draft.userInitials || "AJ").slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div style={{ fontSize: 9, color: "rgba(255,255,255,.5)" }}>
                        Logged in as
                      </div>
                      <div
                        style={{
                          fontSize: 12,
                          fontWeight: 700,
                          color: "white",
                        }}
                      >
                        {draft.userName || "Ashi Jain"}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div
              style={{
                padding: "12px 20px",
                borderTop: "1px solid #EAEAE6",
                display: "flex",
                gap: 8,
                background: "#FAFAFA",
              }}
            >
              <button
                onClick={handleReset}
                style={{
                  flex: 1,
                  padding: "9px 0",
                  border: "1.5px solid #EAEAE6",
                  borderRadius: 8,
                  background: "white",
                  fontSize: 12,
                  fontWeight: 600,
                  cursor: "pointer",
                  color: "#666",
                  fontFamily: "inherit",
                  transition: "border-color .12s",
                }}
              >
                Reset
              </button>
              <button
                onClick={handleApply}
                style={{
                  flex: 2,
                  padding: "9px 0",
                  border: "none",
                  borderRadius: 8,
                  background: draft.accentColor,
                  fontSize: 12,
                  fontWeight: 700,
                  cursor: "pointer",
                  color: "white",
                  fontFamily: "inherit",
                  transition: "filter .12s",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.filter =
                    "brightness(1.08)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.filter = "none";
                }}
              >
                Apply Changes
              </button>
            </div>
          </div>
        </>
      )}
    </>
  );
}

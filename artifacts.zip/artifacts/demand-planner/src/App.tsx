import { useCallback, useEffect, useRef, useState } from "react";
import BrandSettings, {
  BrandConfig,
  DEFAULT_CONFIG,
} from "./components/BrandSettings";

const BASE = import.meta.env.BASE_URL ?? "/";
const STORAGE_KEY = "demand-planner-brand-config";
const CONFIG_VERSION = "v3"; // bump to reset stale localStorage

function loadConfig(): BrandConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // If stored version matches, use it; otherwise reset to defaults
      if (parsed.__version === CONFIG_VERSION) {
        return { ...DEFAULT_CONFIG, ...parsed };
      }
    }
  } catch {}
  return DEFAULT_CONFIG;
}


function saveConfig(config: BrandConfig) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...config, __version: CONFIG_VERSION }));
  } catch {}
}

export default function App() {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [ready, setReady] = useState(false);
  const [config, setConfig] = useState<BrandConfig>(loadConfig);

  // Inject all CSS overrides + text content into the iframe's document
  const applyConfig = useCallback(
    (cfg: BrandConfig, doc?: Document) => {
      const iframeDoc =
        doc ?? iframeRef.current?.contentDocument ?? null;
      if (!iframeDoc) return;

      const root = iframeDoc.documentElement;

      // CSS variables
      root.style.setProperty("--accent", cfg.accentColor);
      root.style.setProperty("--accent-dark", cfg.accentDark);
      root.style.setProperty("--bg", cfg.bgColor);

      // Topbar
      const topbar = iframeDoc.querySelector<HTMLElement>(".topbar");
      if (topbar) topbar.style.background = cfg.topbarColor;

      const brand = iframeDoc.querySelector<HTMLElement>(".brand");
      if (brand) brand.style.background = cfg.topbarColor;

      // Logo text
      const b1 = iframeDoc.querySelector<HTMLElement>(".brand-logo .b1");
      if (b1) {
        b1.textContent = cfg.companyName;
        b1.style.color = cfg.accentColor;
      }
      const b2 = iframeDoc.querySelector<HTMLElement>(".brand-logo .b2");
      if (b2) b2.textContent = cfg.productName;

      // Brand icon fill
      const brandRect = iframeDoc.querySelector<SVGRectElement>(
        ".brand svg rect"
      );
      if (brandRect) brandRect.setAttribute("fill", cfg.accentColor);

      // Greeting
      const pg = iframeDoc.querySelector<HTMLElement>(".pg-title");
      if (pg) pg.textContent = cfg.greeting;

      // Avatar
      const avatar = iframeDoc.querySelector<HTMLElement>(".avatar");
      if (avatar) {
        avatar.textContent = cfg.userInitials.slice(0, 2).toUpperCase();
        avatar.style.background = `linear-gradient(135deg, ${cfg.accentColor}, ${cfg.accentDark})`;
      }

      // User name
      const uinfo = iframeDoc.querySelector<HTMLElement>(".uinfo strong");
      if (uinfo) uinfo.textContent = cfg.userName;

      // Inject a <style> tag to catch any CSS-var-driven colors reactively
      let styleTag = iframeDoc.getElementById("brand-overrides");
      if (!styleTag) {
        styleTag = iframeDoc.createElement("style");
        styleTag.id = "brand-overrides";
        iframeDoc.head.appendChild(styleTag);
      }
      styleTag.textContent = `
        :root {
          --accent: ${cfg.accentColor} !important;
          --accent-dark: ${cfg.accentDark} !important;
          --bg: ${cfg.bgColor} !important;
        }
        .topbar, .brand { background: ${cfg.topbarColor} !important; }
        .brand-logo .b1 { color: ${cfg.accentColor} !important; }
        .avatar { background: linear-gradient(135deg, ${cfg.accentColor}, ${cfg.accentDark}) !important; }
        .tt.on { background: ${cfg.accentColor} !important; color: #fff !important; }
        .ni.on { background: rgba(${hexToRgb(cfg.accentColor)}, .12) !important; color: ${cfg.accentColor} !important; }
        .ni.on .ic svg { stroke: ${cfg.accentDark} !important; }
        .kc.g { border-left-color: ${cfg.accentColor} !important; }
        .kc.g::before { background: ${cfg.accentColor} !important; }
      `;
    },
    []
  );

  const handleIframeLoad = useCallback(() => {
    const doc = iframeRef.current?.contentDocument;
    if (!doc) return;
    setReady(true);
    applyConfig(config, doc);
  }, [config, applyConfig]);

  // Re-apply whenever config changes (after iframe is ready)
  useEffect(() => {
    if (ready) applyConfig(config);
  }, [config, ready, applyConfig]);

  const handleUpdate = useCallback((newConfig: BrandConfig) => {
    setConfig(newConfig);
    saveConfig(newConfig);
  }, []);

  return (
    <div style={{ width: "100vw", height: "100vh", background: config.bgColor }}>
      <iframe
        ref={iframeRef}
        src={`${BASE}dashboard.html`}
        title="Demand Planner Dashboard"
        onLoad={handleIframeLoad}
        style={{
          width: "100%",
          height: "100%",
          border: "none",
          display: "block",
        }}
      />
      <BrandSettings config={config} onUpdate={handleUpdate} />
    </div>
  );
}

function hexToRgb(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return isNaN(r) ? "1,148,129" : `${r},${g},${b}`;
}

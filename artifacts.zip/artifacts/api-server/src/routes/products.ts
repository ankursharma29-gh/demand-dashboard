import { Router } from "express";
import productData from "../product-master.json";

const router = Router();

type Product = {
  "P1 Division": string;
  "P2 Department": string;
  "P3 Category": string;
  "P4 Style": string;
  "P5 Sub-Style": string;
  "P6 Style-Color": string;
  "P7 SKU": string;
  Color: string;
  Size: string;
};

const products: Product[] = productData as Product[];

router.get("/products", (_req, res) => {
  res.json({ count: products.length, products });
});

router.get("/products/styles", (_req, res) => {
  const styles = [...new Set(products.map((p) => p["P4 Style"]))].filter(Boolean);
  res.json({ count: styles.length, styles });
});

router.get("/products/skus", (_req, res) => {
  const skus = products.map((p) => ({
    sku: p["P7 SKU"],
    style: p["P4 Style"],
    subStyle: p["P5 Sub-Style"],
    styleColor: p["P6 Style-Color"],
    department: p["P2 Department"],
    category: p["P3 Category"],
    color: p["Color"],
    size: p["Size"],
  }));
  res.json({ count: skus.length, skus });
});

router.get("/products/hierarchy", (_req, res) => {
  const hierarchy: Record<string, Record<string, Record<string, string[]>>> = {};
  products.forEach((p) => {
    const dept = p["P2 Department"];
    const cat = p["P3 Category"];
    const style = p["P4 Style"];
    if (!hierarchy[dept]) hierarchy[dept] = {};
    if (!hierarchy[dept][cat]) hierarchy[dept][cat] = {};
    if (!hierarchy[dept][cat][style]) hierarchy[dept][cat][style] = [];
    if (!hierarchy[dept][cat][style].includes(p["P7 SKU"])) {
      hierarchy[dept][cat][style].push(p["P7 SKU"]);
    }
  });
  res.json({ hierarchy });
});

export default router;
